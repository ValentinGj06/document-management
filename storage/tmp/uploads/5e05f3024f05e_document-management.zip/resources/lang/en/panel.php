<?php

return [
    'site_title' => 'Document Management',
];
